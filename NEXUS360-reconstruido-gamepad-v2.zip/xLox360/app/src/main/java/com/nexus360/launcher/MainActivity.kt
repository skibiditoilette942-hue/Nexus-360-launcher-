package com.xlox360.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.InputDevice
import android.hardware.input.InputManager
import android.view.MotionEvent
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 8, 7)
    private val panel = Color.rgb(15, 22, 17)
    private val green = Color.rgb(166, 235, 105)
    private val white = Color.rgb(240, 246, 248)
    private val muted = Color.rgb(153, 167, 174)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var clock: TextView
    private val tabViews = linkedMapOf<String, TextView>()
    private var currentTab = "INÍCIO"
    private var lastAnalogMoveAt = 0L
    private val analogRepeatMs = 180L
    private val analogDeadZone = 0.55f
    private var lastAnalogDirection = 0
    private var lastLeftTriggerPressed = false
    private var lastRightTriggerPressed = false
    private val inputManager by lazy { getSystemService(INPUT_SERVICE) as InputManager }
    private val inputDeviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) { /* input is immediately available to Android dispatch */ }
        override fun onInputDeviceRemoved(deviceId: Int) { lastAnalogDirection = 0 }
        override fun onInputDeviceChanged(deviceId: Int) { lastAnalogDirection = 0 }
    }
    private val prefs by lazy { getSharedPreferences("xlox360", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildShell()
        showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(30), dp(20), dp(30), dp(20))
            setBackgroundColor(bg)
            isFocusableInTouchMode = true
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "NEXUS 360"
            textSize = 27f; setTextColor(white); typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.06f
        }
        val stripe = TextView(this).apply { text = "  ■"; textSize = 22f; setTextColor(green) }
        val spacer = Space(this)
        clock = TextView(this).apply { textSize = 17f; setTextColor(muted); gravity = Gravity.CENTER_VERTICAL }
        header.addView(logo); header.addView(stripe); header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f)); header.addView(clock)
        root.addView(header, LinearLayout.LayoutParams(-1, dp(42)))
        val subtitle = TextView(this).apply { text = "A NEW ERA. A FAMILIAR FEELING."; textSize = 10f; letterSpacing = 0.22f; setTextColor(green) }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(22)))
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, dp(14)) }
        listOf("INÍCIO", "JOGOS", "APLICATIVOS", "FAVORITOS", "⚙ CONFIGURAÇÕES").forEach { tab ->
            val b = TextView(this).apply {
                val tabKey = if (tab.startsWith("⚙")) "CONFIGURAÇÕES" else tab
                text = tab; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (tabKey == currentTab) green else muted)
                setPadding(dp(12), dp(9), dp(12), dp(9)); isFocusable = true; isClickable = true
                background = rounded(if (tabKey == currentTab) 0x333CFF00 else Color.TRANSPARENT, 7)
                setOnFocusChangeListener { v, focused ->
                    v.background = rounded(if (tabKey == currentTab || focused) 0x333CFF00 else Color.TRANSPARENT, 7, if (focused) green else Color.TRANSPARENT)
                }
                setOnClickListener { currentTab = tabKey; updateTabStyles(); refresh() }
            }
            tabViews[if (tab.startsWith("⚙")) "CONFIGURAÇÕES" else tab] = b
            tabs.addView(b)
        }
        root.addView(tabs)
        val line = View(this).apply { setBackgroundColor(Color.rgb(43, 57, 62)) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(18), 0, 0) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = TextView(this).apply { text = "• NOSTALGIA REIMAGINADA.  /  PRÉVIA • TV 16:9"; textSize = 9f; letterSpacing = 0.12f; setTextColor(Color.rgb(90, 108, 116)) }
        root.addView(footer)
        setContentView(root)
        updateClock()
    }

    override fun onResume() {
        super.onResume()
        inputManager.registerInputDeviceListener(inputDeviceListener, null)
        if (::root.isInitialized) { updateClock(); refresh() }
    }

    override fun onPause() {
        inputManager.unregisterInputDeviceListener(inputDeviceListener)
        super.onPause()
    }

    private fun updateClock() {
        if (!::clock.isInitialized) return
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greeting = when (hour) { in 5..11 -> "BOM DIA"; in 12..17 -> "BOA TARDE"; else -> "BOA NOITE" }
        clock.text = "$greeting   •   $time"
    }

    private fun updateTabStyles() {
        tabViews.forEach { (key, view) ->
            val selected = key == currentTab
            view.setTextColor(if (selected) green else muted)
            if (!view.hasFocus()) view.background = rounded(if (selected) 0x333CFF00 else Color.TRANSPARENT, 7)
        }
    }

    private fun refresh() {
        if (!::content.isInitialized) return
        updateTabStyles()
        content.removeAllViews()
        when (currentTab) {
            "JOGOS" -> showApps(false, true)
            "APLICATIVOS" -> showApps(false)
            "FAVORITOS" -> showApps(true)
            "CONFIGURAÇÕES" -> showSettings()
            else -> showHome()
        }
    }

    private fun showHome() {
        content.removeAllViews()
        val title = TextView(this).apply { text = "SEU UNIVERSO. CONECTADO."; textSize = 23f; typeface = Typeface.create("sans-serif-black", Typeface.BOLD); setTextColor(white) }
        content.addView(title)
        val desc = TextView(this).apply { text = "Seus aplicativos favoritos em um só lugar."; textSize = 14f; setTextColor(muted); setPadding(0, dp(6), 0, dp(18)) }
        content.addView(desc)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
        val favorites = launcherApps().filter { isFavorite(it.packageName) }.take(4)
        favorites.forEach { app ->
            row.addView(appCard(app, true), LinearLayout.LayoutParams(0, dp(155), 1f).apply { marginEnd = dp(10) })
        }
        // The reference artwork's game titles are examples only: show real user favorites, never hard-coded games.
        row.addView(addItemCard("ADICIONAR ITEM") { currentTab = "APLICATIVOS"; refresh() },
            LinearLayout.LayoutParams(0, dp(155), 1f).apply { marginEnd = dp(10) })
        content.addView(row)
        content.addView(TextView(this).apply {
            text = if (favorites.isEmpty()) "Nenhum item adicionado ainda. Selecione + para escolher um aplicativo e use ☆ para adicioná-lo aos favoritos." else "Selecione + para encontrar aplicativos. Use ☆ na biblioteca para adicioná-los aos favoritos."
            setTextColor(muted); textSize = 12f; setPadding(0, dp(18), 0, 0)
        })
    }

    private fun addItemCard(label: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = rounded(0x221A2618, 12, Color.rgb(50, 72, 43))
            setPadding(dp(8), dp(10), dp(8), dp(10)); isFocusable = true; isClickable = true
            contentDescription = label
        }
        val plus = TextView(this).apply {
            text = "+"; textSize = 34f; typeface = Typeface.DEFAULT; gravity = Gravity.CENTER
            setTextColor(green); background = rounded(0x331A2618, 10)
        }
        box.addView(plus, LinearLayout.LayoutParams(dp(52), dp(52)))
        box.addView(TextView(this).apply {
            text = label; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(green); gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0)
        })
        box.setOnClickListener { action() }
        box.setOnFocusChangeListener { v, focused ->
            v.background = rounded(if (focused) 0xFF26351F.toInt() else 0x221A2618, 12, if (focused) green else Color.rgb(50, 72, 43))
        }
        return box
    }

    private data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable?, val isGame: Boolean)

    private fun launcherApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            packageManager.queryIntentActivities(intent, 0)
                .mapNotNull { info ->
                    val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                    if (pkg == packageName) return@mapNotNull null
                    AppEntry(info.loadLabel(packageManager)?.toString() ?: pkg, pkg, info.loadIcon(packageManager), Build.VERSION.SDK_INT >= 26 && info.activityInfo.applicationInfo.category == ApplicationInfo.CATEGORY_GAME)
                }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        } catch (_: Exception) { emptyList() }
    }

    private fun showApps(favoritesOnly: Boolean, gamesOnly: Boolean = false) {
        val heading = TextView(this).apply { text = if (favoritesOnly) "SEUS FAVORITOS" else "APLICATIVOS INSTALADOS"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white); setPadding(0, 0, 0, dp(12)) }
        content.addView(heading)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val apps = launcherApps().filter { (!favoritesOnly || isFavorite(it.packageName)) && (!gamesOnly || it.isGame) }
        if (apps.isEmpty()) list.addView(TextView(this).apply { text = when { favoritesOnly -> "Ainda não há favoritos. Abra Aplicativos e use ☆ para favoritar."; gamesOnly -> "Nenhum jogo foi identificado pelo Android neste dispositivo."; else -> "Não foram encontrados aplicativos para iniciar." }; setTextColor(muted); textSize = 14f; setPadding(dp(8), dp(12), dp(8), dp(12)) })
        apps.forEach { app ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(0xFF13191E.toInt(), 10); setPadding(dp(12), dp(8), dp(12), dp(8)); isFocusable = true }
            val icon = ImageView(this).apply { setImageDrawable(app.icon); scaleType = ImageView.ScaleType.FIT_CENTER }
            item.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            labels.addView(TextView(this).apply { text = app.label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white) })
            labels.addView(TextView(this).apply { text = app.packageName; textSize = 10f; setTextColor(muted) })
            item.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val fav = TextView(this).apply { text = if (isFavorite(app.packageName)) "★" else "☆"; textSize = 25f; setTextColor(green); gravity = Gravity.CENTER; isFocusable = true; setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { toggleFavorite(app.packageName); refresh() } }
            item.addView(fav)
            item.setOnFocusChangeListener { v, focused ->
                v.background = rounded(if (focused) 0xFF26351F.toInt() else 0xFF13191E.toInt(), 10, if (focused) green else Color.TRANSPARENT)
            }
            item.setOnClickListener { launchApp(app.packageName) }
            list.addView(item, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(7) })
        }
        if (!favoritesOnly) {
            val add = actionButton("＋  ADICIONAR ITEM / VER APLICATIVOS") {
                if (gamesOnly) { currentTab = "APLICATIVOS"; refresh() }
                else Toast.makeText(this, "Selecione ☆ ao lado de um aplicativo para adicioná-lo aos favoritos da tela inicial.", Toast.LENGTH_LONG).show()
            }
            list.addView(add, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        }
        scroll.addView(list)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun showSettings() {
        val title = TextView(this).apply { text = "CONFIGURAÇÕES DO NEXUS 360"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white); setPadding(0, 0, 0, dp(16)) }
        content.addView(title)
        content.addView(actionButton("ABRIR CONFIGURAÇÕES DO ANDROID") { openSettings() }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        content.addView(actionButton("ESCOLHER LAUNCHER PADRÃO (SE DISPONÍVEL)") {
            try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
            catch (_: Exception) { AlertDialog.Builder(this).setMessage("Abra Configurações do Android e procure por Aplicativos padrão ou Tela inicial.").setPositiveButton("OK", null).show() }
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        content.addView(actionButton("VER APLICATIVOS INSTALADOS") { currentTab = "APLICATIVOS"; refresh() }, LinearLayout.LayoutParams(-1, dp(52)))
        content.addView(TextView(this).apply { text = "O Android pode limitar a troca de launcher em algumas TV Boxes. O xLox não precisa de root."; textSize = 12f; setTextColor(muted); setPadding(0, dp(18), 0, 0) })
    }

    private fun appCard(app: AppEntry, showFavorite: Boolean): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(0xFF13191E.toInt(), 12); setPadding(dp(8), dp(10), dp(8), dp(10)); isFocusable = true; isClickable = true }
        val icon = ImageView(this).apply { setImageDrawable(app.icon); scaleType = ImageView.ScaleType.FIT_CENTER }
        box.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        box.addView(TextView(this).apply { text = app.label; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white); gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(8), 0, 0) })
        if (showFavorite) box.addView(TextView(this).apply { text = if (isFavorite(app.packageName)) "★ FAVORITO" else "ABRIR"; textSize = 9f; setTextColor(green); setPadding(0, dp(5), 0, 0) })
        box.setOnClickListener { launchApp(app.packageName) }
        box.setOnFocusChangeListener { v, hasFocus -> v.background = rounded(if (hasFocus) 0xFF26351F.toInt() else 0xFF13191E.toInt(), 12, if (hasFocus) green else Color.TRANSPARENT) }
        return box
    }

    private fun actionButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(white); isFocusable = true; isClickable = true
        background = rounded(0xFF192126.toInt(), 9, Color.rgb(43, 57, 62)); setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { action() }
        setOnFocusChangeListener { v, focus -> v.background = rounded(if (focus) 0xFF26351F.toInt() else 0xFF192126.toInt(), 9, if (focus) green else Color.rgb(43, 57, 62)) }
    }

    private fun launchApp(pkg: String) {
        try { val intent = packageManager.getLaunchIntentForPackage(pkg); if (intent != null) startActivity(intent) else Toast.makeText(this, "Este aplicativo não oferece um atalho de inicialização.", Toast.LENGTH_SHORT).show() }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Não foi possível abrir o aplicativo.", Toast.LENGTH_SHORT).show() }
    }

    private fun openSettings() { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { Toast.makeText(this, "Configurações indisponíveis neste dispositivo.", Toast.LENGTH_SHORT).show() } }
    private fun isFavorite(pkg: String) = prefs.getBoolean("fav_$pkg", false)
    private fun toggleFavorite(pkg: String) { prefs.edit().putBoolean("fav_$pkg", !isFavorite(pkg)).apply() }
    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Let Android's focus system handle D-pad and keyboard navigation first.
        // Normalize common controller confirm/back keys without swallowing unknown keys.
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_BUTTON_A -> {
                    if (event.repeatCount == 0) {
                        val focused = currentFocus
                        if (focused != null && focused.isFocusable && focused.isEnabled) focused.performClick()
                        else root.requestFocus()
                        return true
                    }
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_C -> {
                    if (event.repeatCount == 0 && handleBackNavigation()) return true
                    if (event.repeatCount > 0) return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_BUTTON_B || keyCode == KeyEvent.KEYCODE_BUTTON_C) {
            if ((event?.repeatCount ?: 0) > 0) return true
            if (handleBackNavigation()) return true
        }
        // Xbox/PlayStation face-button aliases vary by controller and Android mapping.
        if (keyCode == KeyEvent.KEYCODE_BUTTON_A) {
            if (event?.repeatCount == 0) {
                currentFocus?.takeIf { it.isFocusable && it.isEnabled }?.performClick()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BUTTON_A,
            KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_C -> true
            else -> super.onKeyUp(keyCode, event)
        }
    }

    private fun handleBackNavigation(): Boolean {
        if (currentTab != "INÍCIO") {
            currentTab = "INÍCIO"
            refresh()
            return true
        }
        return false
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_MOVE &&
            (event.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
            val x = getCenteredAxis(event, MotionEvent.AXIS_X)
            val y = getCenteredAxis(event, MotionEvent.AXIS_Y)
            val rightX = getCenteredAxis(event, MotionEvent.AXIS_RX)
            val rightY = getCenteredAxis(event, MotionEvent.AXIS_RY)
            val hatX = getCenteredAxis(event, MotionEvent.AXIS_HAT_X)
            val hatY = getCenteredAxis(event, MotionEvent.AXIS_HAT_Y)
            val stickX = if (kotlin.math.abs(rightX) > kotlin.math.abs(x)) rightX else x
            val stickY = if (kotlin.math.abs(rightY) > kotlin.math.abs(y)) rightY else y
            val dx = if (kotlin.math.abs(hatX) > kotlin.math.abs(stickX)) hatX else stickX
            val dy = if (kotlin.math.abs(hatY) > kotlin.math.abs(stickY)) hatY else stickY
            val direction = when {
                dx < -analogDeadZone -> View.FOCUS_LEFT
                dx > analogDeadZone -> View.FOCUS_RIGHT
                dy < -analogDeadZone -> View.FOCUS_UP
                dy > analogDeadZone -> View.FOCUS_DOWN
                else -> 0
            }
            val now = SystemClock.uptimeMillis()
            // Some generic USB/Bluetooth pads expose triggers as analog axes.
            val leftTrigger = maxOf(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE)) > 0.75f
            val rightTrigger = maxOf(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS)) > 0.75f
            if (leftTrigger && !lastLeftTriggerPressed) handleBackNavigation()
            if (rightTrigger && !lastRightTriggerPressed) currentFocus?.takeIf { it.isFocusable && it.isEnabled }?.performClick()
            lastLeftTriggerPressed = leftTrigger
            lastRightTriggerPressed = rightTrigger
            if (direction == 0) {
                lastAnalogDirection = 0
            } else if (direction != lastAnalogDirection || now - lastAnalogMoveAt >= analogRepeatMs) {
                moveFocus(direction)
                lastAnalogDirection = direction
                lastAnalogMoveAt = now
            }
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    private fun getCenteredAxis(event: MotionEvent, axis: Int): Float {
        val device = event.device ?: return 0f
        val range = device.getMotionRange(axis, event.source) ?: device.getMotionRange(axis, InputDevice.SOURCE_JOYSTICK)
            ?: return 0f
        val value = event.getAxisValue(axis)
        return if (kotlin.math.abs(value) < range.flat.coerceAtLeast(0.12f)) 0f else value
    }

    private fun moveFocus(direction: Int) {
        val focused = currentFocus ?: root
        val next = focused.focusSearch(direction)
        if (next != null && next !== focused) next.requestFocus()
    }
}
