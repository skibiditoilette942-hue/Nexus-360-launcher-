# NEXUS 360 — Android TV launcher

Projeto Android nativo em Kotlin, sem WebView. Mantém inicialização de aplicativos, favoritos persistentes, relógio/saudação, atalhos para Configurações do Android e navegação por foco para TV Box.

## Alterações desta versão
- Identidade visual atualizada para NEXUS 360, com fundo escuro, acentos verde-limão e navegação horizontal compacta inspirada na referência fornecida.
- Categorias Música e Vídeos não são exibidas. A navegação inclui Início, Jogos, Aplicativos, Favoritos e Configurações. A tela inicial não contém jogos de demonstração fixos: mostra apenas favoritos reais instalados e um cartão + para encontrar/adicionar aplicativos aos favoritos. Jogos filtra aplicativos que o Android identifica como jogos; alguns fabricantes não classificam todos os jogos corretamente.
- A aba Configurações abre as configurações originais do Android e mantém o atalho para selecionar o launcher padrão quando disponível.
- Entrada nativa para controles: D-pad/teclas, A/X para confirmar, B/C para voltar, analógicos esquerdo/direito, hat axes e gatilhos analógicos; dead zone e repetição limitada para reduzir movimentos acidentais.
- Registro de eventos de conexão/desconexão de dispositivos de entrada Android. Toque, teclado e controle remoto continuam disponíveis.
- Os favoritos continuam salvos no mesmo SharedPreferences (`xlox360`), preservando os dados existentes.

## Compilar
1. Abra a pasta `xLox360` no Android Studio.
2. Aguarde a sincronização Gradle. O projeto usa Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21, compileSdk 35, minSdk 23 e Java/Kotlin JVM 17.
3. Instale a plataforma Android SDK 35 e Build Tools compatíveis, se solicitado.
4. Execute **Build > Build APK(s)**. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.
5. Para release, configure sua assinatura de distribuição no Android Studio e execute a tarefa `assembleRelease`.

## Itens da tela inicial
- Jogos/títulos mostrados em imagens de referência não são inseridos como conteúdo fictício. O launcher lista apenas apps detectados no dispositivo.
- O cartão + abre a biblioteca de aplicativos; use o ícone ☆ para adicionar/remover itens dos favoritos exibidos na tela inicial.

## Verificação de controles
- Conecte um controle USB ou pareie um controle Bluetooth nas configurações Android da TV Box.
- Abra o NEXUS 360 e teste D-pad, analógicos, A/Cross, B/Circle e gatilhos.
- Confirme que o foco visível se move entre menus e cartões e que OK abre o item selecionado.
- Teste também toque/teclado/controle remoto para confirmar o fallback.

## Limitações da validação deste pacote
O ambiente em que os arquivos foram ajustados não contém Gradle nem Android SDK configurado; portanto, não foi possível compilar ou testar o APK aqui. A compilação final e o teste físico em controles USB/Bluetooth devem ser feitos no Android Studio e na TV Box. Os mapeamentos dos botões podem variar por fabricante e firmware.
